package masterInjava.Arrays;
class Find_duplicate {
    public static void main(String[] args) {
        int size=3;
        int arr[]={2,2,1};
        for (int i = 0; i < size; i++) {
            int j = Math.abs(arr[i]);
            if (arr[j] >= 0)
                arr[j] = -arr[j];
            else
                System.out.print(j + " ");
        }

    }
}