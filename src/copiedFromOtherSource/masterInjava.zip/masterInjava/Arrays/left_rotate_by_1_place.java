package masterInjava.Arrays;

import java.util.Arrays;

class left_rotate_by_1_place
{
    public static void abc(int arr[],int n)
    {
        int temp=arr[0];
        for(int i=0;i<n-1;i++)
        {
            arr[i]=arr[i+1];
        }
        arr[n-1]=temp;
        System.out.println(Arrays.toString(arr));
    }

    public static void main(String[] args) {
        int n=8;
        int arr[]={2,3,4,5,6,7,8,9};
       abc(arr,n);

    }

}

