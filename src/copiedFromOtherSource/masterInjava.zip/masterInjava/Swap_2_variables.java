package masterInjava;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Dell
 */
import java.util.*;
public class Swap_2_variables {
    public static void main(String args[])
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("enter 2 numbers");
       int a=sc.nextInt();
       int b=sc.nextInt();
    a=a+b;
    b=a-b;
    a=a-b;
    System.out.println("a="+a);
     System.out.println("b="+b); 
}}
