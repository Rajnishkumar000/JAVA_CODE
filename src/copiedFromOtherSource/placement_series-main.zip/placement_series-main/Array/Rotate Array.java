package placement_series for(int i=rotatingindex;i<size;i++)
     {
         System.out.print(array[i]+" ");
     }
     
      for(int i=0;i<rotatingindex;i++)
     {
         System.out.print(array[i]+" ");
     }
