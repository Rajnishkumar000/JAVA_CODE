package placement_series

class Solution
{
    public int maximum_Cuts(int n)
    {
        // code here

 return (n * (n + 1)) / 2 + 1;
                      
    }
}
