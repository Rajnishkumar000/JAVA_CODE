package placement_series

class Solution
{
    public void threeWayPartition(int array[], int a, int b)
    {
        Arrays.sort(array);
    }
}
