package placement_series

public class Main
{
	public static void main(String[] args) {
		int a=111;
		int res=a&1;
		if(res==1)
		{
		    System.out.println("odd");
		}
		else
		{
		    System.out.println("even");
		}
	}
}
