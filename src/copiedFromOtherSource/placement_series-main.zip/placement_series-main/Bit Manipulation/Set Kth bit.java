package placement_series

class Solution{
    static int setKthBit(int N,int K){
        // code here
        return N|(1<<K);
    }
}
