package placement_series Node p=start;
count=0;
while(p!=null)
{
  count=count+1;
  p=p.next;
}
return count;
