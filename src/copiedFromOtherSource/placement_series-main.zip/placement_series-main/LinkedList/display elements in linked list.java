package placement_series Node temp;
temp=start;
while(temp!=null)
{
  System.out.print(temp.data+" ");
  temp=temp.next;
}
