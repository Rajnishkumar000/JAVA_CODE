package placement_series

class Solution {
    ArrayList<Integer> valueEqualToIndex(int arr[], int n) {
        // code here
         ArrayList<Integer> list = new ArrayList<>();
        for(int i=0;i<n;i++){
            if(arr[i]==i+1){
                list.add(i+1);
            }
        }
        return list;
    }
}
