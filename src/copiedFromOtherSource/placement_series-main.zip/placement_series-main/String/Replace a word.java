package placement_series

class Solution {
    static String replaceAll(String str, String oldW, String newW) {
        // code here
          str = str.replace(oldW,newW);
return str;   
    }
}
